<div class="container">
            <div id="accordion">
  <div id="card1" class="card">
    <div id="collapsevse" class="card-header">
      <a class="card-link a:link" data-toggle="collapse" href="#collapseOne">
        Trailer
      </a>
    </div>
    <div id="collapseOne" class="collapse show" data-parent="#accordion">
      <div class="card-body">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ga0iTWXCGa0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        
      </div>
    </div>
  </div>

  <div id="card1" class="card">
    <div id="collapsevse" class="card-header">
      <a class="collapsed card-link a:link" data-toggle="collapse" href="#collapseTwo">
        Behind the Scenes
      </a>
    </div>
    <div id="collapseTwo" class="collapse" data-parent="#accordion">
      <div class="card-body">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/I5TZeyADMWU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>
    </div>
  </div>

    </div>
            
</div>