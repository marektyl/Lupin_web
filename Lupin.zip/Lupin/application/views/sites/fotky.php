     <div class="container">
             <div id="accordion">
  <div id="card1" class="card">
    <div id="collapsevse" class="card-header">
      <a class="card-link a:link" data-toggle="collapse" href="#collapseOne">
        Foto #1
      </a>
    </div>
    <div id="collapseOne" class="collapse show" data-parent="#accordion">
      <div class="card-body">
          
        <img src="https://www.lostwoods.co.uk/wp-content/uploads/2020/09/lupin-netflix.jpg" height="480" width="854" class="mx-auto d-block">
      </div>
    </div>
  </div>

  <div id="card1" class="card">
    <div id="collapsevse" class="card-header">
      <a class="collapsed card-link a:link" data-toggle="collapse" href="#collapseTwo">
        Foto #2
      </a>
    </div>
    <div id="collapseTwo" class="collapse" data-parent="#accordion">
      <div class="card-body">
          
        <img src="https://images.immediate.co.uk/production/volatile/sites/3/2020/12/Teaser202-2-a910a95.jpg?quality=90&resize=620,413" height="480" width="854" class="mx-auto d-block">
      </div>
    </div>
  </div>

  <div id="card1" class="card">
    <div id="collapsevse" class="card-header">
      <a class="collapsed card-link a:link" data-toggle="collapse" href="#collapseThree">
        Foto #3
      </a>
    </div>
    <div id="collapseThree" class="collapse" data-parent="#accordion">
      <div class="card-body">
        
        <img src="https://d13ezvd6yrslxm.cloudfront.net/wp/wp-content/images/Lupin-trailer-700x300.jpg" height="480" width="854" class="mx-auto d-block">
        
      </div>
    </div>
  </div>
       
       