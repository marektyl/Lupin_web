<body>
    <div class="container">
        <div id="card" class="card">
            <div class="card-header"><h1>Lupin</h1></div>
            <div class="card-body">Lupin je francouzský záhadný komediální webový televizní seriál vytvořený Georgem Kayem a Françoisem Uzanem, který měl premiéru na Netflixu 8. ledna 2021. 
              Série se skládá z 10 epizod, které byly vydány ve dvou částech. V seriálu hraje Omar Sy v roli Assane Diopa, muže inspirovaného dobrodružstvím Arsène Lupina, postavy vytvořené Maurice Leblancem.
              Příběh sleduje profesionálního zloděje Assane Diopa, jediného syna přistěhovalce ze Senegalu, který přišel do Francie hledat lepší život pro své dítě. Assanův otec je obviněn z krádeže drahého diamantového náhrdelníku jeho zaměstnavatelem, bohatým a mocným Hubertem Pellegrinim, a kvůli hanbě se oběsí ve své vězeňské cele a mladistvému ​​Assanovi zanechá sirotka. O dvacet pět let později, inspirovaný knihou o gentlemanovi zloději Arsène Lupinovi, kterého mu jeho otec dal k jeho narozeninám, se Assane vydává pomstít Pellegriniho rodině, přičemž pomocí svého charismatu a ovládnutí krádeže, lsti a přestrojení odhalil Hubertovy trestné činy.
            </div>
        </div>
    <div class="row">        
<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    
  </ul>

   <div class="carousel-inner" >
    <div class="carousel-item active">
    <img src="https://www.lostwoods.co.uk/wp-content/uploads/2020/09/lupin-netflix.jpg" class="d-block w-100" alt="random1">
      <div class="carousel-caption">
        
  </div>
    </div>
    <div class="carousel-item">
    <img src="https://images.immediate.co.uk/production/volatile/sites/3/2020/12/Teaser202-2-a910a95.jpg?quality=90&resize=620,413" class="d-block w-100" alt="random2">
      <div class="carousel-caption">
    
  
    </div>
  </div>

  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
    
    </div>
          
          
</body>

    </div>
