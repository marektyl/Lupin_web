
<div class="container">
   <div class="row justify-content-center">
  <nav class="navbar navbar-expand-lg bg-danger navbar-dark">
     <a class="navbar-brand" href="<?php echo base_url('')?>">
    <img src="<?php echo base_url('img/Logo_lupin.jpg')?>" alt="Logo" style="width:60px;">
    </a>    
  <ul class="navbar-nav">
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Fotky a videa
        </a>
        <div class="dropdown-menu bg-secondary" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="<?php echo base_url('fotky')?>"><i class="fas fa-camera-retro"></i> Fotky</a>
          <a class="dropdown-item" href="<?php echo base_url('videa')?>"><i class="fas fa-play-circle"></i> Videa</a>
      </li>
  <li class="nav-item">
    <a class="nav-link" href="https://en.wikipedia.org/wiki/Lupin_(TV_series)"><i class="fab fa-wikipedia-w"></i> wikipedie</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" data-toggle="tooltip" data-placement="bottom" title="Každý zná ČSFD." href="https://www.csfd.cz/film/929143-lupin/prehled/"><i class="fas fa-tasks"></i> Dalši informace</a>
  </li>
  <script>
    $(document).ready(function(){
     $('[data-toggle="tooltip"]').tooltip(); 
    });
</script>
  
  </ul>   
   </nav>   
  </div>
</div>