<?php

class Pages extends CI_Controller
{   
    public function home()
    {
        
        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('sites/home');
        $this->load->view('templates/footer');
    }
    
    public function fotky()
    {
        
        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('sites/fotky');
        $this->load->view('templates/footer');
    }
    
    public function videa()
    {
        
        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('sites/videa');
        $this->load->view('templates/footer');
    }
    
    
}
?>



